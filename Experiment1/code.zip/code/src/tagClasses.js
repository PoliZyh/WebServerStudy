const tagClasses = {
    liveHrefTag: '.c-blocka.wa-olympic-schedule-item.OP_LOG_BTN', // 能够拿到直播间href的tag
    competitionName: '.first-title.white-color-8.c-line-clamp2 span', // 能够拿到比赛名字的tag
    peopleTag: '.text-position-talkroom' // 能够拿到直播间人数的tag
}



module.exports = tagClasses