
// 根api，即某一天的api路径 需要拼接日期如 2023-09-21
const API_ROOT = 'https://tiyu.baidu.com/major/home/%E6%9D%AD%E5%B7%9E%E4%BA%9A%E8%BF%90%E4%BC%9A/tab/%E8%B5%9B%E7%A8%8B/date/'
// 直播间后缀 即 ’直播间‘
const API_LIVE_SUFFIEX = '%E8%81%8A%E5%A4%A9%E5%AE%A4'

module.exports = {
    API_ROOT,
    API_LIVE_SUFFIEX
}